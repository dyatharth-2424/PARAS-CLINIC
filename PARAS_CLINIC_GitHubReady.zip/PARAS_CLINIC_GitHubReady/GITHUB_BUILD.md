# PARAS CLINIC — GitHub APK Build

This repository is configured to build a debug Android APK using GitHub Actions.

After the repository is uploaded:
1. Push/commit the files to the `main` branch.
2. Open the **Actions** tab.
3. Open **Build PARAS CLINIC APK**.
4. Wait for the workflow to finish successfully.
5. Open the completed workflow run.
6. Download the artifact named **PARAS-CLINIC-debug-apk**.
7. Extract the ZIP to get the APK.
8. Install the APK on the Android phone.

No Android Studio is required on the phone.
