# PARAS CLINIC — Stage 7

## Medicine editing and removal
- Each added medicine now has EDIT and REMOVE buttons.
- EDIT loads all fields back into the entry form.
- UPDATE MEDICINE replaces the same medicine in its original position.
- CANCEL EDIT abandons changes.
- REMOVE deletes the medicine immediately from the current prescription.
- Prescription numbering updates automatically.
- Template loading and saving continue to work with the edited prescription.
- Advice, follow-up calculation, A5 preview and A5 printing remain included.


## Stage 8 additions
- Faster prescription frequency choices:
  - 1-0-0
  - 0-1-0
  - 0-0-1
  - 1-0-1
  - 1-1-1
  - 1-1-1-1
  - 1-1-1-1-1
  - 1/2-0-1/2
  - 1/2-1/2-1/2
  - SOS
  - HS
  - Before Food
  - After Food
- Fractional dose frequency parsing is supported for quantity calculation.
- Non-fixed frequencies such as SOS/HS/food-timing are treated as instruction-style frequencies and do not generate an automatic tablet count from the frequency alone; manual quantity can still be entered.
