package com.parasclinic

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

@Dao
interface TemplateDao {
    @Query("SELECT * FROM prescription_templates ORDER BY favourite DESC, name COLLATE NOCASE")
    fun observeTemplates(): Flow<List<PrescriptionTemplate>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveTemplate(template: PrescriptionTemplate): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveItems(items: List<TemplateItem>)

    @Query("SELECT * FROM template_items WHERE templateId = :templateId ORDER BY id")
    suspend fun getItems(templateId: Long): List<TemplateItem>

    @Query("DELETE FROM template_items WHERE templateId = :templateId")
    suspend fun deleteItems(templateId: Long)

    @Query("DELETE FROM prescription_templates WHERE id = :id")
    suspend fun deleteTemplate(id: Long)

    @Query("UPDATE prescription_templates SET name = :name WHERE id = :id")
    suspend fun renameTemplate(id: Long, name: String)

    @Query("UPDATE prescription_templates SET favourite = :favourite WHERE id = :id")
    suspend fun setFavourite(id: Long, favourite: Boolean)

    @Transaction
    suspend fun saveComplete(template: PrescriptionTemplate, items: List<TemplateItem>) {
        val id = saveTemplate(template)
        saveItems(items.map { it.copy(templateId = id) })
    }

    @Transaction
    suspend fun replaceComplete(template: PrescriptionTemplate, items: List<TemplateItem>) {
        deleteItems(template.id)
        saveItems(items.map { it.copy(templateId = template.id, id = 0) })
        saveTemplate(template)
    }
}
