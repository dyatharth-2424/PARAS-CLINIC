package com.parasclinic

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "advices")
data class Advice(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val text: String
)
