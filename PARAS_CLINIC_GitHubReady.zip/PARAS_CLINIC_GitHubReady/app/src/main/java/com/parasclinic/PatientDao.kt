package com.parasclinic

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface PatientDao {
    @Query("SELECT * FROM patients ORDER BY name COLLATE NOCASE")
    fun observePatients(): Flow<List<Patient>>

    @Query("SELECT * FROM patients WHERE patientId LIKE '%' || :query || '%' OR name LIKE '%' || :query || '%' ORDER BY name COLLATE NOCASE")
    fun searchPatients(query: String): Flow<List<Patient>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun save(patient: Patient)
}
