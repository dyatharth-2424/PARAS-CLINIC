package com.parasclinic

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [Patient::class, Medicine::class, Advice::class, PrescriptionTemplate::class, TemplateItem::class],
    version = 3,
    exportSchema = false
)
abstract class ClinicDatabase : RoomDatabase() {
    abstract fun patientDao(): PatientDao
    abstract fun medicineDao(): MedicineDao
    abstract fun adviceDao(): AdviceDao
    abstract fun templateDao(): TemplateDao

    companion object {
        @Volatile private var INSTANCE: ClinicDatabase? = null
        fun get(context: Context): ClinicDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext, ClinicDatabase::class.java, "paras_clinic.db"
                ).fallbackToDestructiveMigration().build().also { INSTANCE = it }
            }
    }
}
