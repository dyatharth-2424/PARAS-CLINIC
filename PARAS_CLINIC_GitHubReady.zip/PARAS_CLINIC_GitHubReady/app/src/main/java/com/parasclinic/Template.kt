package com.parasclinic

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "prescription_templates")
data class PrescriptionTemplate(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val advice: String = "",
    val favourite: Boolean = false
)

@Entity(tableName = "template_items")
data class TemplateItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val templateId: Long,
    val medicine: String,
    val form: String,
    val dose: String,
    val frequency: String,
    val duration: Int,
    val instructions: String,
    val quantity: Double,
    val unit: String
)
