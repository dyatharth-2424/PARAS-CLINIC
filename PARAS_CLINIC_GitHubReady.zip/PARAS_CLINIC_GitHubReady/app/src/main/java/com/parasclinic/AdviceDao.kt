package com.parasclinic

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface AdviceDao {
    @Query("SELECT * FROM advices ORDER BY text COLLATE NOCASE")
    fun observe(): Flow<List<Advice>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun save(advice: Advice)

    @Query("DELETE FROM advices WHERE id = :id")
    suspend fun delete(id: Long)
}
