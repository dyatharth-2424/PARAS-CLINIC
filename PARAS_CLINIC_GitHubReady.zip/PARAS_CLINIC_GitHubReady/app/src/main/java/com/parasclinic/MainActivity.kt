package com.parasclinic

import android.content.Context
import android.os.Bundle
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.WebView
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.viewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

data class PrescriptionItem(
    val medicine: String, val form: String, val dose: String, val frequency: String,
    val duration: Int, val instructions: String, val quantity: Double, val unit: String
)

class PatientViewModel(private val dao: PatientDao) : ViewModel() {
    var search by mutableStateOf("")
    val patients: StateFlow<List<Patient>> = snapshotFlow { search }
        .flatMapLatest { q -> if (q.isBlank()) dao.observePatients() else dao.searchPatients(q) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    fun save(id: String, name: String) { if (id.isNotBlank() && name.isNotBlank()) viewModelScope.launch { dao.save(Patient(id.trim(), name.trim())) } }
}

class MedicineViewModel(private val dao: MedicineDao) : ViewModel() {
    var search by mutableStateOf("")
    val medicines: StateFlow<List<Medicine>> = snapshotFlow { search }
        .flatMapLatest { q -> if (q.isBlank()) dao.observeMedicines() else dao.searchMedicines(q) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    fun save(name: String, form: String) { if (name.isNotBlank()) viewModelScope.launch { dao.save(Medicine(name = name.trim(), form = form)) } }
    fun delete(id: Long) { viewModelScope.launch { dao.delete(id) } }
}

class AdviceViewModel(private val dao: AdviceDao) : ViewModel() {
    val advices = dao.observe().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    fun save(text: String) { if (text.isNotBlank()) viewModelScope.launch { dao.save(Advice(text = text.trim())) } }
    fun delete(id: Long) { viewModelScope.launch { dao.delete(id) } }
}

class TemplateViewModel(private val dao: TemplateDao) : ViewModel() {
    val templates = dao.observeTemplates().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    suspend fun items(id: Long) = dao.getItems(id)

    fun save(name: String, items: List<PrescriptionItem>, advice: List<String>) {
        if (name.isBlank() || items.isEmpty()) return
        viewModelScope.launch {
            val t = PrescriptionTemplate(name = name.trim(), advice = advice.joinToString("\n"))
            dao.saveComplete(t, items.map { i ->
                TemplateItem(
                    templateId = 0, medicine=i.medicine, form=i.form, dose=i.dose,
                    frequency=i.frequency, duration=i.duration, instructions=i.instructions,
                    quantity=i.quantity, unit=i.unit
                )
            })
        }
    }

    fun rename(id: Long, name: String) {
        if (name.isBlank()) return
        viewModelScope.launch { dao.renameTemplate(id, name.trim()) }
    }

    fun toggleFavourite(template: PrescriptionTemplate) {
        viewModelScope.launch { dao.setFavourite(template.id, !template.favourite) }
    }

    fun delete(id: Long) {
        viewModelScope.launch {
            dao.deleteItems(id)
            dao.deleteTemplate(id)
        }
    }
}

class PatientVMFactory(private val dao: PatientDao) : ViewModelProvider.Factory { override fun <T : ViewModel> create(c: Class<T>): T = PatientViewModel(dao) as T }
class MedicineVMFactory(private val dao: MedicineDao) : ViewModelProvider.Factory { override fun <T : ViewModel> create(c: Class<T>): T = MedicineViewModel(dao) as T }
class AdviceVMFactory(private val dao: AdviceDao) : ViewModelProvider.Factory { override fun <T : ViewModel> create(c: Class<T>): T = AdviceViewModel(dao) as T }
class TemplateVMFactory(private val dao: TemplateDao) : ViewModelProvider.Factory { override fun <T : ViewModel> create(c: Class<T>): T = TemplateViewModel(dao) as T }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = ClinicDatabase.get(this)
        setContent { MaterialTheme { ParasClinicApp(
            patientVm = viewModel(factory = PatientVMFactory(db.patientDao())),
            medicineVm = viewModel(factory = MedicineVMFactory(db.medicineDao())),
            adviceVm = viewModel(factory = AdviceVMFactory(db.adviceDao())),
            templateVm = viewModel(factory = TemplateVMFactory(db.templateDao())),
            printContext = this@MainActivity
        ) } }
    }
}

@Composable
fun ParasClinicApp(patientVm: PatientViewModel, medicineVm: MedicineViewModel, adviceVm: AdviceViewModel, templateVm: TemplateViewModel, printContext: Context) {
    var screen by remember { mutableStateOf("home") }
    var selectedPatient by remember { mutableStateOf<Patient?>(null) }
    when (screen) {
        "medicines" -> MedicineLibraryScreen(medicineVm) { screen = "home" }
        "advices" -> AdviceLibraryScreen(adviceVm) { screen = "home" }
        "templates" -> TemplateLibraryScreen(templateVm) { screen = "home" }
        "prescription" -> selectedPatient?.let { patient ->
            PrescriptionScreen(patient, medicineVm, adviceVm, templateVm,
                onBack = { screen = "home"; selectedPatient = null },
                onPrint = { p, advice, follow -> printPrescription(printContext, patient, p, advice, follow) })
        }
        "new" -> NewPatientDialog(onDismiss = { screen = "home" }, onSave = { id, name -> patientVm.save(id, name); selectedPatient = Patient(id.trim(), name.trim()); screen = "prescription" })
        else -> HomeScreen(patientVm, onMedicines={screen="medicines"}, onAdvices={screen="advices"}, onTemplates={screen="templates"}, onPatient={selectedPatient=it;screen="prescription"}, onNew={screen="new"})
    }
}

@Composable
fun HomeScreen(patientVm: PatientViewModel, onMedicines:()->Unit, onAdvices:()->Unit, onTemplates:()->Unit, onPatient:(Patient)->Unit, onNew:()->Unit) {
    Scaffold(topBar={TopAppBar(title={Text("PARAS CLINIC", fontWeight=FontWeight.Bold)})}) { padding ->
        Column(Modifier.padding(padding).padding(16.dp).fillMaxSize()) {
            Button(onClick=onNew, Modifier.fillMaxWidth()){Text("+ NEW PATIENT")}
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick=onTemplates, Modifier.fillMaxWidth()){Text("PRESCRIPTION TEMPLATES")}
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick=onAdvices, Modifier.fillMaxWidth()){Text("ADVICE LIBRARY")}
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick=onMedicines, Modifier.fillMaxWidth()){Text("MEDICINE LIBRARY")}
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(value=patientVm.search,onValueChange={patientVm.search=it},label={Text("Search Patient ID or Name")},singleLine=true,modifier=Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            val patients by patientVm.patients.collectAsState()
            LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)){items(patients,key={it.patientId}){p->Card(Modifier.fillMaxWidth()){TextButton(onClick={onPatient(p)},Modifier.fillMaxWidth()){Column(Modifier.fillMaxWidth().padding(6.dp)){Text(p.name,fontWeight=FontWeight.Bold);Text("Patient ID: ${p.patientId}")}}}}}
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MedicineLibraryScreen(vm: MedicineViewModel,onBack:()->Unit){
    var name by remember{mutableStateOf("")}; var form by remember{mutableStateOf("Tablet")}; var menu by remember{mutableStateOf(false)}; val meds by vm.medicines.collectAsState()
    Scaffold(topBar={TopAppBar(title={Text("Medicine Library")},navigationIcon={TextButton(onClick=onBack){Text("←")}})}){padding->Column(Modifier.padding(padding).padding(14.dp).fillMaxSize()){
        OutlinedTextField(name,{name=it},label={Text("Medicine name")},singleLine=true,modifier=Modifier.fillMaxWidth());Spacer(Modifier.height(8.dp))
        ExposedDropdownMenuBox(expanded=menu,onExpandedChange={menu=!menu}){OutlinedTextField(form,{},readOnly=true,label={Text("Form")},trailingIcon={ExposedDropdownMenuDefaults.TrailingIcon(menu)},modifier=Modifier.menuAnchor().fillMaxWidth());ExposedDropdownMenu(menu,{menu=false}){listOf("Tablet","Capsule","Syrup","Cream","Ointment","Other").forEach{DropdownMenuItem(text={Text(it)},onClick={form=it;menu=false})}}}
        Spacer(Modifier.height(8.dp));Button(onClick={vm.save(name,form);name=""},enabled=name.isNotBlank(),Modifier.fillMaxWidth()){Text("SAVE MEDICINE")};Spacer(Modifier.height(12.dp))
        OutlinedTextField(vm.search,{vm.search=it},label={Text("Search library")},singleLine=true,modifier=Modifier.fillMaxWidth());Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement=Arrangement.spacedBy(6.dp)){items(meds,key={it.id}){m->Card(Modifier.fillMaxWidth()){Row(Modifier.fillMaxWidth().padding(10.dp),horizontalArrangement=Arrangement.SpaceBetween){Column(Modifier.weight(1f)){Text(m.name,fontWeight=FontWeight.Bold);Text(m.form)};TextButton(onClick={vm.delete(m.id)}){Text("DELETE")}}}}}
    }}
}

@Composable
fun AdviceLibraryScreen(vm: AdviceViewModel,onBack:()->Unit){
    var text by remember{mutableStateOf("")}; val advices by vm.advices.collectAsState()
    Scaffold(topBar={TopAppBar(title={Text("Advice Library")},navigationIcon={TextButton(onClick=onBack){Text("←")}})}){padding->Column(Modifier.padding(padding).padding(14.dp).fillMaxSize()){
        OutlinedTextField(text,{text=it},label={Text("Advice (English / Marathi)")},minLines=2,modifier=Modifier.fillMaxWidth());Spacer(Modifier.height(8.dp));Button(onClick={vm.save(text);text=""},enabled=text.isNotBlank(),Modifier.fillMaxWidth()){Text("SAVE ADVICE")};Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement=Arrangement.spacedBy(6.dp)){items(advices,key={it.id}){a->Card(Modifier.fillMaxWidth()){Row(Modifier.fillMaxWidth().padding(10.dp),horizontalArrangement=Arrangement.SpaceBetween){Text(a.text,Modifier.weight(1f));TextButton(onClick={vm.delete(a.id)}){Text("DELETE")}}}}}
    }}
}

@Composable
fun TemplateLibraryScreen(vm: TemplateViewModel,onBack:()->Unit){
    var editingId by remember { mutableStateOf<Long?>(null) }
    var editName by remember { mutableStateOf("") }
    val templates by vm.templates.collectAsState()

    Scaffold(topBar={
        TopAppBar(title={Text("Prescription Templates")},
            navigationIcon={TextButton(onClick=onBack){Text("←")}})
    }) { padding ->
        Column(Modifier.padding(padding).padding(14.dp).fillMaxSize()) {
            Text("Choose a saved template while prescribing.", style=MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(10.dp))
            if (templates.isEmpty()) {
                Text("No templates saved yet.")
            }
            LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)) {
                items(templates,key={it.id}) { t ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp)) {
                            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) {
                                Text(if(t.favourite) "★ ${t.name}" else t.name,
                                    fontWeight=FontWeight.Bold)
                                Text("${t.id}")
                            }
                            if(t.advice.isNotBlank()) Text("Advice saved")
                            Row(horizontalArrangement=Arrangement.spacedBy(4.dp)) {
                                TextButton(onClick={vm.toggleFavourite(t)}) {
                                    Text(if(t.favourite) "UNFAVOURITE" else "FAVOURITE")
                                }
                                TextButton(onClick={
                                    editingId=t.id
                                    editName=t.name
                                }) { Text("EDIT NAME") }
                                TextButton(onClick={vm.delete(t.id)}) { Text("DELETE") }
                            }
                            if(editingId==t.id) {
                                OutlinedTextField(
                                    value=editName,
                                    onValueChange={editName=it},
                                    label={Text("Template name")},
                                    singleLine=true,
                                    modifier=Modifier.fillMaxWidth()
                                )
                                Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                                    Button(onClick={
                                        vm.rename(t.id,editName)
                                        editingId=null
                                    },enabled=editName.isNotBlank()){Text("SAVE")}
                                    TextButton(onClick={ { editingId=null } }){Text("CANCEL")}
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PrescriptionScreen(patient:Patient,medicineVm:MedicineViewModel,adviceVm:AdviceViewModel,templateVm:TemplateViewModel,onBack:()->Unit,onPrint:(List<PrescriptionItem>,List<String>,String)->Unit){
    var medicine by remember{mutableStateOf("")};var form by remember{mutableStateOf("Tablet")};var dose by remember{mutableStateOf("1")};var frequency by remember{mutableStateOf("1-0-1")};var duration by remember{mutableStateOf("5")};var instructions by remember{mutableStateOf("")};var manualQty by remember{mutableStateOf("")}
    var showMed by remember{mutableStateOf(false)};var showForm by remember{mutableStateOf(false)};var showFreq by remember{mutableStateOf(false)};var showAdvice by remember{mutableStateOf(false)};var showTemplate by remember{mutableStateOf(false)};var templateMessage by remember{mutableStateOf("")};var editingIndex by remember{mutableStateOf<Int?>(null)}
    var items by remember{mutableStateOf(listOf<PrescriptionItem>())};var selectedAdvices by remember{mutableStateOf(listOf<String>())}
    val meds by medicineVm.medicines.collectAsState();val advices by adviceVm.advices.collectAsState();val templates by templateVm.templates.collectAsState(); val scope = rememberCoroutineScope()
    val matching=meds.filter{medicine.isBlank()||it.name.contains(medicine,true)};val days=duration.toIntOrNull()?:0;val freqTotal=frequency.split("-").sumOf{it.toDoubleOrNull()?:0.0}
    val defaultQty=when(form){"Syrup"->(dose.toDoubleOrNull()?:0.0)*freqTotal*days;"Cream","Ointment"->freqTotal*days;else->(dose.toDoubleOrNull()?:0.0)*freqTotal*days};val qty=manualQty.toDoubleOrNull()?:defaultQty
    val follow=calculateFollowUpDate(items)
    Scaffold(topBar={TopAppBar(title={Text("Prescription")},navigationIcon={TextButton(onClick=onBack){Text("←")}})}){padding->LazyColumn(Modifier.padding(padding).padding(14.dp),verticalArrangement=Arrangement.spacedBy(9.dp)){
        item{Text("Patient: ${patient.name}",fontWeight=FontWeight.Bold);Text("Patient ID: ${patient.patientId}");Text(SimpleDateFormat("dd:MM:yyyy",Locale.getDefault()).format(Date()),Modifier.fillMaxWidth())}
        item{HorizontalDivider()}
        item{ExposedDropdownMenuBox(expanded=showTemplate,onExpandedChange={showTemplate=!showTemplate}){OutlinedTextField(if(templateMessage.isBlank())"Choose Prescription Template" else templateMessage,{},readOnly=true,label={Text("Template")},trailingIcon={ExposedDropdownMenuDefaults.TrailingIcon(showTemplate)},modifier=Modifier.menuAnchor().fillMaxWidth());ExposedDropdownMenu(showTemplate,{showTemplate=false}){if(templates.isEmpty())DropdownMenuItem(text={Text("No templates saved yet")},onClick={}) else templates.forEach{t->DropdownMenuItem(text={Text(t.name)},onClick={scope.launch { val loaded=templateVm.items(t.id); items=loaded.map { x -> PrescriptionItem(x.medicine,x.form,x.dose,x.frequency,x.duration,x.instructions,x.quantity,x.unit) }; selectedAdvices=if(t.advice.isBlank()) emptyList() else t.advice.split("\n").filter{it.isNotBlank()}; medicine=""; templateMessage=t.name }; showTemplate=false})}}}}
        item{if(templateMessage.isNotBlank() && templateMessage!="NEW")Text("Template loaded: $templateMessage") }
        item{Text(if(editingIndex==null)"Add Medicine" else "Edit Medicine",style=MaterialTheme.typography.titleLarge);
if(editingIndex!=null)Text("Change the fields below, then tap UPDATE MEDICINE.")}
        item{ExposedDropdownMenuBox(expanded=showMed,onExpandedChange={showMed=!showMed}){OutlinedTextField(medicine,{medicine=it;showMed=true},label={Text("Medicine — search / select")},singleLine=true,trailingIcon={ExposedDropdownMenuDefaults.TrailingIcon(showMed)},modifier=Modifier.menuAnchor().fillMaxWidth());ExposedDropdownMenu(showMed,{showMed=false}){matching.take(12).forEach{m->DropdownMenuItem(text={Text("${m.name}  •  ${m.form}")},onClick={medicine=m.name;form=m.form;showMed=false})}}}}
        item{ExposedDropdownMenuBox(expanded=showForm,onExpandedChange={showForm=!showForm}){OutlinedTextField(form,{},readOnly=true,label={Text("Form")},trailingIcon={ExposedDropdownMenuDefaults.TrailingIcon(showForm)},modifier=Modifier.menuAnchor().fillMaxWidth());ExposedDropdownMenu(showForm,{showForm=false}){listOf("Tablet","Capsule","Syrup","Cream","Ointment","Other").forEach{DropdownMenuItem(text={Text(it)},onClick={form=it;showForm=false})}}}}
        item{Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){OutlinedTextField(dose,{dose=it},label={Text(if(form=="Syrup")"Dose (mL)" else "Dose")},singleLine=true,modifier=Modifier.weight(1f));OutlinedTextField(duration,{duration=it.filter(Char::isDigit)},label={Text("Days")},singleLine=true,modifier=Modifier.width(100.dp))}}
        item{ExposedDropdownMenuBox(expanded=showFreq,onExpandedChange={showFreq=!showFreq}){OutlinedTextField(frequency,{},readOnly=true,label={Text("Frequency")},trailingIcon={ExposedDropdownMenuDefaults.TrailingIcon(showFreq)},modifier=Modifier.menuAnchor().fillMaxWidth());ExposedDropdownMenu(showFreq,{showFreq=false}){listOf("1-0-0","0-0-1","1-0-1","1-1-1","1-1-1-1","0-1-0","1-1-1-1-1").forEach{DropdownMenuItem(text={Text(it)},onClick={frequency=it;showFreq=false})}}}}
        item{Text("Calculated quantity: ${formatQty(qty)} ${unitFor(form)}");OutlinedTextField(manualQty,{manualQty=it},label={Text("Manual quantity (optional)")},singleLine=true,modifier=Modifier.fillMaxWidth())}
        item{OutlinedTextField(instructions,{instructions=it},label={Text("Medicine instructions (English / Marathi)")},minLines=2,modifier=Modifier.fillMaxWidth())}
        item{
    Button(
        onClick={
            if(medicine.isNotBlank()&&days>0&&qty>0){
                val newItem=PrescriptionItem(medicine.trim(),form,dose,frequency,days,instructions,qty,unitFor(form))
                val idx=editingIndex
                items=if(idx==null) items+newItem else items.toMutableList().also{it[idx]=newItem}
                editingIndex=null
                medicine="";dose="1";duration="5";instructions="";manualQty=""
            }
        },
        Modifier.fillMaxWidth()
    ){Text(if(editingIndex==null)"ADD MEDICINE +" else "UPDATE MEDICINE")}
}
item{
    if(editingIndex!=null){
        OutlinedButton(
            onClick={editingIndex=null;medicine="";dose="1";duration="5";instructions="";manualQty=""},
            Modifier.fillMaxWidth()
        ){Text("CANCEL EDIT")}
    }
}
        item{
    if(items.isNotEmpty()){
        Column(verticalArrangement=Arrangement.spacedBy(6.dp)){
            Text("ADDED MEDICINES",style=MaterialTheme.typography.titleMedium)
            items.forEachIndexed{index,i->
                Card(Modifier.fillMaxWidth()){
                    Column(Modifier.padding(10.dp)){
                        Text("${index+1}. ${i.form.uppercase()} ${i.medicine}",fontWeight=FontWeight.Bold)
                        Text("${i.dose}   ${i.frequency} × ${i.duration} days   Qty: ${formatQty(i.quantity)} ${i.unit}")
                        if(i.instructions.isNotBlank()) Text("→ ${i.instructions}")
                        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){
                            OutlinedButton(
                                onClick={
                                    editingIndex=index
                                    medicine=i.medicine;form=i.form;dose=i.dose
                                    frequency=i.frequency;duration=i.duration.toString()
                                    instructions=i.instructions;manualQty=i.quantity.toString()
                                },
                                Modifier.weight(1f)
                            ){Text("EDIT")}
                            OutlinedButton(
                                onClick={
                                    items=items.toMutableList().also{it.removeAt(index)}
                                    if(editingIndex==index){
                                        editingIndex=null;medicine="";dose="1";duration="5";instructions="";manualQty=""
                                    }
                                },
                                Modifier.weight(1f)
                            ){Text("REMOVE")}
                        }
                    }
                }
            }
        }
    }
}
item{HorizontalDivider();Text("ADVICE",style=MaterialTheme.typography.titleLarge);ExposedDropdownMenuBox(expanded=showAdvice,onExpandedChange={showAdvice=!showAdvice}){OutlinedTextField("Choose advice",{},readOnly=true,label={Text("Add from Advice Library")},trailingIcon={ExposedDropdownMenuDefaults.TrailingIcon(showAdvice)},modifier=Modifier.menuAnchor().fillMaxWidth());ExposedDropdownMenu(showAdvice,{showAdvice=false}){advices.forEach{a->DropdownMenuItem(text={Text(a.text)},onClick={if(!selectedAdvices.contains(a.text))selectedAdvices=selectedAdvices+a.text;showAdvice=false})}}}}
        item{if(selectedAdvices.isNotEmpty())Column(verticalArrangement=Arrangement.spacedBy(5.dp)){selectedAdvices.forEach{a->Card(Modifier.fillMaxWidth()){Row(Modifier.fillMaxWidth().padding(8.dp),horizontalArrangement=Arrangement.SpaceBetween){Text(a,Modifier.weight(1f));TextButton(onClick={selectedAdvices=selectedAdvices.filterNot{it==a}}){Text("REMOVE")}}}}}}
        item{if(items.isNotEmpty()){Column{HorizontalDivider();Text("PRESCRIPTION",style=MaterialTheme.typography.titleLarge);A5PreviewCard(patient,items,selectedAdvices,follow);Spacer(Modifier.height(8.dp));Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Button(onClick={onPrint(items,selectedAdvices,follow)},Modifier.weight(1f)){Text("PRINT A5")};Button(onClick={templateMessage="NEW";},Modifier.weight(1f)){Text("SAVE AS TEMPLATE")}};if(templateMessage=="NEW")SaveTemplateDialog(onDismiss={templateMessage=""},onSave={name->templateVm.save(name,items,selectedAdvices);templateMessage=""})}}}
    }}
}

@Composable
fun NewPatientDialog(onDismiss:()->Unit,onSave:(String,String)->Unit){
    var id by remember{mutableStateOf("")};var name by remember{mutableStateOf("")}
    AlertDialog(onDismissRequest=onDismiss,title={Text("New Patient")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){OutlinedTextField(id,{id=it},label={Text("Patient ID")},singleLine=true);OutlinedTextField(name,{name=it},label={Text("Patient Name")},singleLine=true)}},confirmButton={TextButton(onClick={if(id.isNotBlank()&&name.isNotBlank())onSave(id,name)}){Text("SAVE & PRESCRIBE")}},dismissButton={TextButton(onClick=onDismiss){Text("CANCEL")}})
}

@Composable
fun SaveTemplateDialog(onDismiss:()->Unit,onSave:(String)->Unit){var name by remember{mutableStateOf("")};AlertDialog(onDismissRequest=onDismiss,title={Text("Save Prescription as Template")},text={OutlinedTextField(name,{name=it},label={Text("Template name e.g. FUNGAL1")},singleLine=true)},confirmButton={TextButton(onClick={if(name.isNotBlank())onSave(name)}){Text("SAVE")}},dismissButton={TextButton(onClick=onDismiss){Text("CANCEL")}})}

@Composable
fun A5PreviewCard(patient:Patient,items:List<PrescriptionItem>,advices:List<String>,followUpDate:String){val today=SimpleDateFormat("dd:MM:yyyy",Locale.getDefault()).format(Date());Card(Modifier.fillMaxWidth().heightIn(min=620.dp)){Column(Modifier.padding(12.dp)){Spacer(Modifier.height(210.dp));Text(today,Modifier.fillMaxWidth());Spacer(Modifier.height(8.dp));Text("Patient ID: ${patient.patientId}",fontWeight=FontWeight.Bold);Text("Patient Name: ${patient.name}",fontWeight=FontWeight.Bold);Spacer(Modifier.height(12.dp));HorizontalDivider();Spacer(Modifier.height(8.dp));items.forEachIndexed{index,i->Text("${index+1}. ${i.form.uppercase()}  ${i.medicine}",fontWeight=FontWeight.Bold);Text("Dose: ${i.dose}    ${i.frequency}    ${i.duration} days    Qty: ${formatQty(i.quantity)} ${i.unit}");if(i.instructions.isNotBlank())Text("→ ${i.instructions}");Spacer(Modifier.height(7.dp))};if(advices.isNotEmpty()){Spacer(Modifier.height(3.dp));Text("ADVICE",fontWeight=FontWeight.Bold);advices.forEach{Text("• $it")}};Spacer(Modifier.height(8.dp));HorizontalDivider();Spacer(Modifier.height(8.dp));Text("Follow-up: $followUpDate",fontWeight=FontWeight.Bold)}}}

fun calculateFollowUpDate(items:List<PrescriptionItem>):String{if(items.isEmpty())return "—";val cal=Calendar.getInstance();cal.add(Calendar.DAY_OF_YEAR,items.maxOf{it.duration}+1);if(cal.get(Calendar.DAY_OF_WEEK)==Calendar.SUNDAY)cal.add(Calendar.DAY_OF_YEAR,1);return SimpleDateFormat("dd:MM:yyyy",Locale.getDefault()).format(cal.time)}
fun unitFor(form:String)=when(form){"Tablet"->"tablets";"Capsule"->"capsules";"Syrup"->"mL";"Cream","Ointment"->"application";else->"units"}
fun formatQty(v:Double)=if(v%1.0==0.0)v.toInt().toString() else String.format(Locale.getDefault(),"%.1f",v)

fun printPrescription(context:Context,patient:Patient,items:List<PrescriptionItem>,advices:List<String>,followUpDate:String){val webView=WebView(context);val today=SimpleDateFormat("dd:MM:yyyy",Locale.getDefault()).format(Date());fun esc(v:String)=v.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;");val rows=items.mapIndexed{idx,i->"<div class='medicine'><b>${idx+1}. ${esc(i.form.uppercase())} ${esc(i.medicine)}</b><div>Dose: ${esc(i.dose)} &nbsp;&nbsp; ${esc(i.frequency)} &nbsp;&nbsp; ${i.duration} days &nbsp;&nbsp; Qty: ${formatQty(i.quantity)} ${esc(i.unit)}</div>${if(i.instructions.isNotBlank())"<div>→ ${esc(i.instructions)}</div>" else ""}</div>"}.joinToString("");val adviceHtml=if(advices.isNotEmpty())"<div class='advice'><b>ADVICE</b>${advices.joinToString(""){"<div>• ${esc(it)}</div>"}}</div>" else "";val html="""<html><head><meta charset='utf-8'><style>@page{size:A5 portrait;margin:8mm}body{margin:0;font-family:sans-serif;font-size:11pt}.letterhead-space{height:76.2mm}.date{text-align:right;margin-bottom:5mm}.line{border-top:1px solid #000;margin:3mm 0}.medicine{margin:0 0 4mm}.advice{margin-top:4mm}.followup{border-top:1px solid #000;margin-top:5mm;padding-top:3mm;font-weight:bold}</style></head><body><div class='letterhead-space'></div><div class='date'>$today</div><div><b>Patient ID:</b> ${esc(patient.patientId)}<br><b>Patient Name:</b> ${esc(patient.name)}</div><div class='line'></div>$rows$adviceHtml<div class='followup'>Follow-up: $followUpDate</div></body></html>""".trimIndent();webView.settings.javaScriptEnabled=false;webView.loadDataWithBaseURL(null,html,"text/html","UTF-8",null);webView.postDelayed({val pm=context.getSystemService(Context.PRINT_SERVICE) as PrintManager;pm.print("PARAS CLINIC - ${patient.name}",webView.createPrintDocumentAdapter("PARAS_CLINIC_${patient.patientId}"),PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A5).setMinMargins(PrintAttributes.Margins.NO_MARGINS).build())},700)}
